<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.2
 */

?>

		</div><!-- #content -->
		
    <!-- Footer -->
    <footer class="py-5 bg-black">
      <div class="container">
        <p class="m-0 text-center text-white small">Copyright &copy; Klub Buku Yogyakarta 2018<br>Some images are taken from https://www.instagram.com/grantdraws/ with permission.</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="/wp-content/themes/twentyseventeen/vendor/jquery/jquery.min.js"></script>
    <script src="/wp-content/themes/twentyseventeen/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="/wp-content/themes/twentyseventeen/vendor/sweetalert/sweetalert-dev.js"></script>
    <script>
        function join() {
            swal({
                title : 'Bergabung',
                text :'Ingin bergabung dengan WAG KBY?<br>Sila kirimkan pesan berisi permintaan bergabung ke nomor: <br></br>085726668050 atau 085869888611<br><br>dan mengisi formulir yang ada di pranala berikut: <a href="http://bit.ly/FormAnggotaBaruKBY" target="_blank">bit.ly/FormAnggotaBaruKBY</a>',
                html:true,
                type: 'info',
                confirmButtonText: 'Baik!',
                });
        }
    </script>

		<!--footer id="colophon" class="site-footer" role="contentinfo">
			<div class="wrap">
				<?php
				get_template_part( 'template-parts/footer/footer', 'widgets' );

				if ( has_nav_menu( 'social' ) ) : ?>
					<nav class="social-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Footer Social Links Menu', 'twentyseventeen' ); ?>">
						<?php
							wp_nav_menu( array(
								'theme_location' => 'social',
								'menu_class'     => 'social-links-menu',
								'depth'          => 1,
								'link_before'    => '<span class="screen-reader-text">',
								'link_after'     => '</span>' . twentyseventeen_get_svg( array( 'icon' => 'chain' ) ),
							) );
						?>
					
				<?php endif;

				get_template_part( 'template-parts/footer/site', 'info' );
				?>
			</div>
		</footer-->
	</div><!-- .site-content-contain -->
</div><!-- #page -->
<?php wp_footer(); ?>

</body>
</html>
