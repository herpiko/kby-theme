<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>KBY - Dari Yogya, dengan buku kita rangkul dunia!</title>

    <!-- Bootstrap core CSS -->
    <link href="/wp-content/themes/twentyseventeen/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Custom styles for this template -->
    <link href="/wp-content/themes/twentyseventeen/css/one-page-wonder.css" rel="stylesheet">
    <link href="/wp-content/themes/twentyseventeen/vendor/sweetalert/sweetalert.css" rel="stylesheet">
    <link rel="shortcut icon" href="/wp-content/themes/twentyseventeen/favicon.ico?version=3" />
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'twentyseventeen' ); ?></a>

	<!--header id="masthead" class="site-header" role="banner">

		<?php get_template_part( 'template-parts/header/header', 'image' ); ?>

		<?php if ( has_nav_menu( 'top' ) ) : ?>
			<div class="navigation-top">
				<div class="wrap">
					<?php get_template_part( 'template-parts/navigation/navigation', 'top' ); ?>
				</div>
			</div>
		<?php endif; ?>

	</header--><!-- #masthead -->

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-custom fixed-top">
      <div class="container">
        <img src="/wp-content/themes/twentyseventeen/img/kby-logo-blue.jpg" style="height:50px;margin-right:15px;">
        <a class="navbar-brand" href="/">Klub Buku Yogyakarta</a>
        <button class="navbar-light navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="/kegiatan">Kegiatan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/pengurus">Pengurus</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/category/blog/">Blog</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/tentang">Tentang KBY</a></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <header class="masthead text-center text-white">
      <div class="masthead-content">
        <div class="container">
          
          <? 
            $pagePath = parse_url( $_SERVER['REQUEST_URI'] );
            $pagePath = $pagePath['path'];
            $pagePath = substr($pagePath, 1, -1);
            if ($pagePath =='') {
                echo '<h1 class="masthead-heading mb-0">Klub Buku Yogyakarta</h1><h2 class="masthead-subheading mb-0" style="color:white !important;">Dari Yogya, dengan buku kita rangkul dunia!</h2>';
            } else if ($pagePath =='kegiatan') {
                echo '<h2 class="masthead-subheading" style="color:white !important;">Kegiatan-kegiatan yang ada di KBY</h2>';
            } else if ($pagePath =='tentang') {
                echo '<h2 class="masthead-subheading" style="color:white !important;">Tentang KBY</h2>';
            } else if ($pagePath =='pengurus') {
                echo '<h2 class="masthead-subheading" style="color:white !important;">Kutu-kutu di belakang KBY</h2>';
            } else if ($pagePath =='category/blog') {
                echo '<h2 class="masthead-subheading" style="color:white !important;">Blog</h2>';
            } else {
                global $post;
                echo '<h2 class="masthead-subheading" style="color:white !important;">'.$post->post_title.'</h2>';
            }
          ?>
          <a href="#" class="btn btn-primary btn-xl rounded-pill mt-5" onclick="join()">Gabung</a>
        </div>
        <? if ($pagePath == '') { ?>
        
        <div class="container">
          <div class="row align-items-center">
            <div class="col-lg-6 order-lg-2">
              <div class="p-5">
                <img class="img-fluid rounded-circle" src="/wp-content/themes/twentyseventeen/img/grantdraws02.jpg" alt="">
              </div>
            </div>
            <div class="col-lg-6 order-lg-1">
              <div class="p-5">
                <p>
                Klub Buku Yogyakarta sebuah komunitas yang beranggotakan orang-orang yang menjadikan membaca sebagai kegemarannya. Klub Buku Yogyakarta pertama kali hadir dan memeriahkan ranah pertwitteran pada April 2012. Dan hingga saat ini, setelah berusia hampir 6 tahun, follower Klub Buku Yogya sudah mencapai hampir 2000 orang.
                </p>
              </div>
            </div>
          </div>
          <div class="row" style="display:block;margin-top:50px;text-align:center;font-size:50px;color:white;">
                  <a href="https://twitter.com/KlubBuku_Yogya" target="_blank" class="fa fa-twitter"></a>
                  <a href="https://www.instagram.com/klubbuku_yogya/" target="_blank" class="fa fa-instagram"></a>
                  <a href="#" onClick="join()" class="fa fa-whatsapp"></a>
          </div>
          <? } ?>
        </div>
      </div>

      <div class="bg-circle-1 bg-circle"></div>
      <div class="bg-circle-2 bg-circle"></div>
      <div class="bg-circle-3 bg-circle"></div>
      <div class="bg-circle-4 bg-circle"></div>
    </header>


	<?php

	/*
	 * If a regular post or page, and not the front page, show the featured image.
	 * Using get_queried_object_id() here since the $post global may not be set before a call to the_post().
	 */
	if ( ( is_single() || ( is_page() && ! twentyseventeen_is_frontpage() ) ) && has_post_thumbnail( get_queried_object_id() ) ) :
		echo '<div class="single-featured-image-header">';
		echo get_the_post_thumbnail( get_queried_object_id(), 'twentyseventeen-featured-image' );
		echo '</div><!-- .single-featured-image-header -->';
	endif;
	?>

	<div class="site-content-contain">
		<div id="content" class="site-content">

